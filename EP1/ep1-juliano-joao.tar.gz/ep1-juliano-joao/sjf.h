#ifndef _SJF_H_
#define _SJF_H_

#include <time.h>
#include "process.h"

void schedulerSJF(ProcArray);

#endif
