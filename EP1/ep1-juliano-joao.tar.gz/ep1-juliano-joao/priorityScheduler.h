#ifndef _PRIORITY_SCHEDULER_H_
#define _PRIORITY_SCHEDULER_H_

#include <time.h>
#include "process.h"


void schedulerPriority(ProcArray);

#endif
