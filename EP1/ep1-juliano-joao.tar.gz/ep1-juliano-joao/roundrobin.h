#ifndef _ROUNDROBIN_H_
#define _ROUNDROBIN_H_

#include <time.h>
#include "process.h"

void schedulerRoundRobin(ProcArray);

#endif
